﻿namespace Parcial_1_condicionales
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Ingresar los siguientes datos del empleado:

Nombre del empleado.
Número de años trabajados en la empresa.
Calificación del año actual (0.0, 0.4, 0.6, 1.0).
Calificación del año anterior (debe ser uno de los mismos valores anteriores).

2. Validar que las calificaciones ingresadas estén entre los valores permitidos.

Si la calificación actual no corresponde a ninguno de los valores válidos (0.0, 0.4, 0.6, 1.0), el programa debe mostrar un mensaje de error y terminar inmediatamente.

3. Calcular el promedio de las dos calificaciones (año actual y anterior).

4. Según el número de años trabajados y el promedio de calificación, determinar el porcentaje de aumento salarial utilizando las siguientes reglas:

añosTrabajados < 1  =   0%
añosTrabajados > 5  =   30%
0 < añosTrabajados <= 5 y 0 <= promedioCalificación < 0.4    =    5%
0 < añosTrabajados <= 5 y 0.4 <= promedioCalificación < 0.6    =   10%
0 < añosTrabajados <= 5 y 0.6 <= promedioCalificación <= 1.0   =   20%

     5. Todos los empleados tienen un sueldo base fijo de $2.500.000.
        El aumento se calcula como:  valorAumento = sueldoBase×(porcentajeAumento/100​)
                                   
6. El programa debe mostrar al final:
Nombre del empleado.
Promedio de la calificación.
Porcentaje de aumento aplicado.
Valor del aumento en pesos.*/

            string nombre = "";
            float añostrabajados = 0;
            float calificacionaño = 0;
            char años = ' ';
         
            Console.WriteLine("ingrese el nombre del empleado");
            nombre = Console.ReadLine();
            Console.WriteLine(nombre);
            Console.WriteLine("ingrese los años trabajados: 2:dos años, 3:tres años, 4:cuatro años, 5:cinco años");
            años = Convert.ToChar(Console.ReadLine());


            switch (años)
            {
                case '2':
                    añostrabajados = calificacionaño * 0.0f;
                    Console.WriteLine($"la calificacion del año actual es: {añostrabajados = calificacionaño}");
                    break;

                case '3':
                    añostrabajados = calificacionaño * 0.4f;
                    Console.WriteLine($"la calificacion del año es: {añostrabajados = calificacionaño}");
                    break;













            }
            

           









   





        }
    }
}
